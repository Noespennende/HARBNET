﻿using Gruppe8.HarbNet;

namespace HarbNet.Brukertesting
{
    internal class Oppgave1
    {
        static void Main(string[] args)
        {
            /* ** OPPGAVE 1 ** */

            // Opprett ett stort skip med navn "Titanic", med 30 halv-containere og 70 full-size containere.
            // Skipet bruker 7 dager på en tur.

            /* !! Svar på oppgaven under her !! */


        }
    }
}
