﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gruppe8.HarbNet;

namespace HarbNet.Brukertesting
{
    internal class Oppgave2
    {
        static void Main(string[] args)
        {
            /* ** OPPGAVE 2 ** */

            // Du skal lage lagringsplassen til en havn.
            // Lag 15 container rader med plass til 10 containere per rad.

            /* !! Svar på oppgaven under her !! */

        }
    }
}
