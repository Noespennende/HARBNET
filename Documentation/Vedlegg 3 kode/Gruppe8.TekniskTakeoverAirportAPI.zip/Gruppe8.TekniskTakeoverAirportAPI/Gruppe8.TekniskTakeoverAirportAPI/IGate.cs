﻿
namespace Gruppe8.TekniskTakeoverAirportAPI
{
    public interface IGate
    {
        IList<Flight> AssignedFlights { get; }
        int Capacity { get; }
        int GateId { get; }
        GateGroup Group { get; }
        bool IsAvailable { get; }

        void AssignFlight(Flight flight, Plane plane);
        void ReleaseFlight(Flight flight);
    }
}