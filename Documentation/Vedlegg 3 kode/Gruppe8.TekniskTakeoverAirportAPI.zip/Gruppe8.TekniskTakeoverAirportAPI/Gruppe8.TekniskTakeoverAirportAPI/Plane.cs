﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gruppe8.TekniskTakeoverAirportAPI
{

    public class Plane : IPlane
    {
        public Guid PlaneID { get; }

        public string Model { get; }

        public int Seats { get; }

        public int Weight { get; }

        public PlaneSize planeSize { get; }

        public Plane(Guid planeID, string model, int seats, int weight, PlaneSize planeSize)
        {
            PlaneID = planeID;
            Model = model;
            Seats = seats;
            Weight = weight;
            this.planeSize = planeSize;
        }
    }
}
