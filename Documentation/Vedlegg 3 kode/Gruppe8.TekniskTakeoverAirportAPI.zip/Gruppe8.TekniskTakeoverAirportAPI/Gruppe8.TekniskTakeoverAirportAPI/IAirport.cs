﻿
namespace Gruppe8.TekniskTakeoverAirportAPI
{
    public interface IAirport
    {
        int AirportCode { get; }
        IList<Gate> Gates { get; }
        string Name { get; }

        // Adding a list with all planes in the airport at a given time.
        IList<Plane> planesInAirport { get; }
        IList<Runway> Runways { get; }
        void AddGate(Gate gate);
        void AddRunway(Runway runway);
        Runway GetAvailableRunwayForArrival();
        Runway GetAvailableRunwayForDeparture();

        // Guid for IDs and not int
        int GetQueueTime(Guid gateId);
        int GetTakeoffTime(Plane plane);
       
        Gate RemoveGate(Gate gate);
        Runway RemoveRunway(Runway runway);

        // Moved ReserveRunway and ReleaseRunway to Airport from Runway class.
        void ReserveRunway();
        void ReleaseRunway();

        // Moved AssignGate in FlightData to Airport and renamed with more descriptive naming.
        // Airport is the "overseeing" class and should therefore consider to handle most if not all communication between classes
        void AssignArrivingPlaneToGate(Gate gate, Flight flightData);
    }
}