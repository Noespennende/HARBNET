﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Gruppe8.TekniskTakeoverAirportAPI
{

    // Changed name from FlightData to Flight
    public class Flight : IFlight
    {
        public Airport DepartureAirport { get; }
        public DateTime DepartureTime { get; set; }
        public string Destination { get; }
        public Gate AssignedGate { get; private set; }
        public Plane Plane { get; set; }

        public Flight(Airport departureAirport, DateTime departureTime, string destination, Gate assignedGate, Plane plane)
        {
            DepartureAirport = departureAirport;
            DepartureTime = departureTime;
            Destination = destination;
            AssignedGate = assignedGate;
            Plane = plane;
        }
    }
}
