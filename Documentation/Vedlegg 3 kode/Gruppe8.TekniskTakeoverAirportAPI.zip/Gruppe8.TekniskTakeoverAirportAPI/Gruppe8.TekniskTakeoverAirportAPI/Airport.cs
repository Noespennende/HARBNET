﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Xml.Linq;

namespace Gruppe8.TekniskTakeoverAirportAPI
{
    public class Airport : IAirport
    {
        public int AirportCode { get; }

        public string Name { get; }

        public IList<Gate> Gates { get; }

        public IList<Runway> Runways { get; }

        // Adding a list with all planes in the airport at a given time.
        public IList<Plane> planesInAirport { get; private set; } 


        public Airport(int airportCode, string name)
        {
            AirportCode = airportCode;
            Name = name;
            Gates = new List<Gate>();
            Runways = new List<Runway>();
            planesInAirport = new List<Plane>();
        }

        public void AddGate(Gate gate) { }

        public void AddRunway(Runway runway) { }

        public Runway GetAvailableRunwayForDeparture() { throw new NotImplementedException(); }

        // Added method to get an available runway to use for arriving plane.
        public Runway GetAvailableRunwayForArrival() { throw new NotImplementedException(); }

        // Guid for IDs and not int
        public int GetQueueTime(Guid gateId) { throw new NotImplementedException(); }

        public int GetTakeoffTime(Plane plane) { throw new NotImplementedException(); }

        // New method: Remove gate 
        public Gate RemoveGate(Gate gate) { throw new NotImplementedException(); }

        public Runway RemoveRunway(Runway runway) { throw new NotImplementedException(); }

        // Moved ReserveRunway and ReleaseRunway to Airport from Runway class.
        public void ReserveRunway() { throw new NotImplementedException(); }

        public void ReleaseRunway() { throw new NotImplementedException(); }

        // Moved AssignGate in Fligh(tData) to Airport and renamed with more descriptive naming.
        public void AssignArrivingPlaneToGate(Gate gate, Flight flightData) { throw new NotImplementedException(); }

    };
}
