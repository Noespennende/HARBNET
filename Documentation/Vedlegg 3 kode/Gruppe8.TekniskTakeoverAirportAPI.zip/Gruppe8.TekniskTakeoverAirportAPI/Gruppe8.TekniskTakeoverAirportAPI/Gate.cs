﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gruppe8.TekniskTakeoverAirportAPI
{

    public class Gate : IGate
    {
        public int GateId { get; }
        public bool IsAvailable { get; private set; }
        public int Capacity { get; }
        public IList<Flight> AssignedFlights { get; }
        public GateGroup Group { get; }


        public Gate(int gateId, int capacity, GateGroup group) { throw new NotImplementedException(); }


        public void AssignFlight(Flight flight, Plane plane) { throw new NotImplementedException(); }


        public void ReleaseFlight(Flight flight) { throw new NotImplementedException(); }
    }
}
