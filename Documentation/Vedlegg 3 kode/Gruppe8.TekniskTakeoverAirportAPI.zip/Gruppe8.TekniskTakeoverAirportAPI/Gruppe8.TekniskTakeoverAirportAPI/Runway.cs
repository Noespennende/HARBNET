﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gruppe8.TekniskTakeoverAirportAPI
{

    public class Runway
    {
        public Guid RunwayId { get; }
        public bool IsAvailable { get; private set; }
        public int Length { get; }
        public int TimeToTakeoff { get; }
        public int TimeToLand { get; }

        // Added a queue for the planes waiting to takeoff, so we can know which planes are expected at said Runway. Planes are waiting by the gates.
        public Queue<Plane> planesInTakeoffQueue { get; private set; }

        public Runway(Guid runwayId, bool isAvailable, int length, Queue<Plane> planesInTakeoffQueue, int timeToTakeoff = 180, int timeToLand = 900)
        {
            RunwayId = runwayId;
            IsAvailable = isAvailable;
            Length = length;
            this.planesInTakeoffQueue = planesInTakeoffQueue;
            TimeToTakeoff = timeToTakeoff;
            TimeToLand = timeToLand;
        }


        // Moved ReserveRunway and ReleaseRunway to Airport


    }
}
