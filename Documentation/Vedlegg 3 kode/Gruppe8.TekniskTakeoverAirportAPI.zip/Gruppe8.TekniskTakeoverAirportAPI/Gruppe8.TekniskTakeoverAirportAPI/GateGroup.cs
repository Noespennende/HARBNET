﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gruppe8.TekniskTakeoverAirportAPI
{
    public enum GateGroup
    {
        /// <summary>
        /// A is the gate used for international flights.
        /// </summary>
        A,
        /// <summary>
        /// B is the gate used for domestic flights.
        /// </summary>
        B,
        /// <summary>
        /// C is the gate used for connecting flights.
        /// </summary>
        C
    }
}
