﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gruppe8.TekniskTakeoverAirportAPI
{
    // Moved these methods into a Simulation class
    public class Simulation
    {
        static void SimulateFlightOperations(Airport airport, List<Plane> planes) { throw new NotImplementedException(); }

        static void SimulateArrivals(Airport airport, List<Plane> planes, ref DateTime currentTime) { throw new NotImplementedException(); }

        static void SimulateDepartures(Airport airport, ref DateTime currentTime) { throw new NotImplementedException(); }

        static void GetFlightHistoryFromDateToDate(string filePath, DateTime fromDate, DateTime toDate) { throw new NotImplementedException(); }
    }
}
