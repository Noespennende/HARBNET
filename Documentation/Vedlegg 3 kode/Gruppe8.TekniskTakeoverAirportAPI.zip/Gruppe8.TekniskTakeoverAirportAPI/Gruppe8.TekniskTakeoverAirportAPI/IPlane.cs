﻿
namespace Gruppe8.TekniskTakeoverAirportAPI
{
    public interface IPlane
    {
        string Model { get; }
        Guid PlaneID { get; }
        PlaneSize planeSize { get; }
        int Seats { get; }
        int Weight { get; }
    }
}