﻿
namespace Gruppe8.TekniskTakeoverAirportAPI
{
    public interface IFlight
    {
        Gate AssignedGate { get; }
        Airport DepartureAirport { get; }
        DateTime DepartureTime { get; set; }
        string Destination { get; }
        Plane Plane { get; set; }
    }
}